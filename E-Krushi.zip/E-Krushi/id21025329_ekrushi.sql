-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Nov 02, 2023 at 01:05 PM
-- Server version: 10.5.20-MariaDB
-- PHP Version: 7.3.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `id21025329_ekrushi`
--

-- --------------------------------------------------------

--
-- Table structure for table `app_version`
--

CREATE TABLE `app_version` (
  `id` bigint(20) NOT NULL,
  `version_code` int(11) NOT NULL,
  `version_name` varchar(50) NOT NULL,
  `active` tinyint(1) NOT NULL,
  `created_at` bigint(20) NOT NULL,
  `last_update` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `app_version`
--

INSERT INTO `app_version` (`id`, `version_code`, `version_name`, `active`, `created_at`, `last_update`) VALUES
(2, 2, '2', 1, 1485795799112, 1485795799112);

-- --------------------------------------------------------

--
-- Table structure for table `cart_product`
--

CREATE TABLE `cart_product` (
  `user_id` bigint(20) NOT NULL,
  `product_id` bigint(20) NOT NULL,
  `quantity` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cart_product`
--

INSERT INTO `cart_product` (`user_id`, `product_id`, `quantity`) VALUES
(1, 147, 1);

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` bigint(20) NOT NULL,
  `name` varchar(50) NOT NULL,
  `icon` varchar(100) NOT NULL,
  `draft` tinyint(1) NOT NULL,
  `brief` varchar(100) NOT NULL,
  `color` varchar(7) NOT NULL,
  `priority` int(11) NOT NULL DEFAULT 0,
  `created_at` bigint(20) NOT NULL,
  `last_update` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `name`, `icon`, `draft`, `brief`, `color`, `priority`, `created_at`, `last_update`) VALUES
(16, 'Seeds', '1689098957554.png', 0, 'Seeds Online | Buy Best Quality Agricultural Seeds Online', '#ffffff', 1, 1687080225348, 1689098957554),
(17, 'Fertilizers', '1689099023042.png', 0, 'Fertilizers', '#ffffff', 2, 1687080708488, 1689099023042),
(18, 'Insecticides', '1689099049228.png', 0, 'Insecticides', '#ffffff', 3, 1687080869201, 1689099049228);

-- --------------------------------------------------------

--
-- Table structure for table `config`
--

CREATE TABLE `config` (
  `code` varchar(50) NOT NULL,
  `grouping` varchar(50) NOT NULL,
  `value` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `config`
--

INSERT INTO `config` (`code`, `grouping`, `value`) VALUES
('EMAIL_ORDER', 'EMAIL', '{\"bcc_receiver\":[\"your-admin1@mail.com\",\"your-admin2@mail.com\"],\"notif_order\":true,\"notif_order_process\":true,\"reply_to\":\"dipaktarfe2@gmail.com\"}'),
('EMAIL_SMTP', 'EMAIL', '{\"email\":\"dipaktarfe2@gmail.com\",\"password\":\"Pass@123\",\"host\":\"mail.your-domain.com\",\"port\":\"111\"}'),
('EMAIL_TEXT', 'EMAIL', '{\"subject_email_new_order\":\"Market New Order\",\"title_report_new_order\":\"Market New Order\",\"subject_email_order_processed\":\"Order PROCESSED\",\"title_report_order_processed\":\"Order Status Change to PROCESSED\",\"subject_email_order_updated\":\"Order Data Updated\",\"title_report_order_updated\":\"Order Data Updated\"}'),
('GENERAL', 'GENERAL', '{\"currency\":\"INR\",\"tax\":11,\"featured_news\":5}'),
('NOTIF_KEY', 'NOTIF', '{\"fcm_key\":\"XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX\",\"one_signal_appid\":\"XXXXXXXXXXXXXXXXXXXXXXX\",\"one_signal_rest_key\":\"XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX\"}'),
('NOTIF_TITLE', 'NOTIF', '{\"new_product\":\"New Product\",\"update_product\":\"Update Product\"}'),
('PAYMENT_BANK', 'PAYMENT', '{\"active\":true,\"instruction\":\"<div><b>INSTRUCTION :&nbsp;</b></div><ol><li>Pay an amount of <b>[@amount]</b> to one of our bank numbers, the difference in the amount will cause the order become fail or delay payment confirmation..</li><li>Write the order code <b>[@code]</b> on the pay reference.</li><li>Confirmation by send your&nbsp;<span style=\\\"\\\\&quot;color:\\\" rgb(77,=\\\"\\\" 81,=\\\"\\\" 86);=\\\"\\\" font-family:=\\\"\\\" arial,=\\\"\\\" sans-serif;\\\\\\\"=\\\"\\\">Payment Slip</span>&nbsp;to WhatsApp number&nbsp;<b>123456789</b>&nbsp;or email <b>sample@gmail.com</b></li><li>Your order will be processed and ship immediately.</li></ol><b>BANK ACCOUNT :</b><br><ul><li>BANK XXX : <b>1234567-23671-2367</b> name aExpress Admin</li><li>BANK YYY :&nbsp;<b><b>1234567</b>-23671-2367</b> name aExpress&nbsp;Admin</li></ul>\"}'),
('PAYMENT_PAYPAL', 'PAYMENT', '{\"active\":true,\"client_id\":\"YourPaypalClientId\",\"secret\":\"YourPaypalSecretId\",\"mode\":\"SANDBOX\"}'),
('PAYMENT_RAZORPAY', 'PAYMENT', '{\"active\":true,\"key_id\":\"rzp_test_wc24Nhpfn6vVML\",\"key_secret\":\"hBWwa5UrVIu2UeQgemaOg3Dv\"}');

-- --------------------------------------------------------

--
-- Table structure for table `currency`
--

CREATE TABLE `currency` (
  `id` bigint(20) NOT NULL,
  `code` varchar(3) NOT NULL,
  `name` varchar(100) NOT NULL,
  `paypal` tinyint(1) NOT NULL,
  `razorpay` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `currency`
--

INSERT INTO `currency` (`id`, `code`, `name`, `paypal`, `razorpay`) VALUES
(1, 'AFA', 'Afghanistan afghani', 0, 0),
(2, 'ALL', 'Albanian lek', 0, 1),
(3, 'DZD', 'Algerian dinar', 0, 1),
(4, 'AOR', 'Angolan kwanza reajustado', 0, 0),
(5, 'ARS', 'Argentine peso', 0, 1),
(6, 'AMD', 'Armenian dram', 0, 1),
(7, 'AWG', 'Aruban guilder', 0, 1),
(8, 'AUD', 'Australian dollar', 1, 1),
(9, 'AZN', 'Azerbaijanian new manat', 0, 0),
(10, 'BSD', 'Bahamian dollar', 0, 1),
(11, 'BHD', 'Bahraini dinar', 0, 0),
(12, 'BDT', 'Bangladeshi taka', 0, 1),
(13, 'BBD', 'Barbados dollar', 0, 1),
(14, 'BYN', 'Belarusian ruble', 0, 0),
(15, 'BZD', 'Belize dollar', 0, 1),
(16, 'BMD', 'Bermudian dollar', 0, 1),
(17, 'BTN', 'Bhutan ngultrum', 0, 0),
(18, 'BOB', 'Bolivian boliviano', 0, 1),
(19, 'BWP', 'Botswana pula', 0, 1),
(20, 'BRL', 'Brazilian real', 1, 0),
(21, 'GBP', 'British pound', 1, 1),
(22, 'BND', 'Brunei dollar', 0, 1),
(23, 'BGN', 'Bulgarian lev', 0, 0),
(24, 'BIF', 'Burundi franc', 0, 0),
(25, 'KHR', 'Cambodian riel', 0, 1),
(26, 'CAD', 'Canadian dollar', 1, 1),
(27, 'CVE', 'Cape Verde escudo', 0, 0),
(28, 'KYD', 'Cayman Islands dollar', 0, 1),
(29, 'XOF', 'CFA franc BCEAO', 0, 0),
(30, 'XAF', 'CFA franc BEAC', 0, 0),
(31, 'XPF', 'CFP franc', 0, 0),
(32, 'CLP', 'Chilean peso', 0, 0),
(33, 'CNY', 'Chinese yuan renminbi', 1, 1),
(34, 'COP', 'Colombian peso', 0, 1),
(35, 'KMF', 'Comoros franc', 0, 0),
(36, 'CDF', 'Congolese franc', 0, 0),
(37, 'CRC', 'Costa Rican colon', 0, 1),
(38, 'HRK', 'Croatian kuna', 0, 1),
(39, 'CUP', 'Cuban peso', 0, 1),
(40, 'CZK', 'Czech koruna', 1, 1),
(41, 'DKK', 'Danish krone', 1, 1),
(42, 'DJF', 'Djibouti franc', 0, 0),
(43, 'DOP', 'Dominican peso', 0, 1),
(44, 'XCD', 'East Caribbean dollar', 0, 0),
(45, 'EGP', 'Egyptian pound', 0, 1),
(46, 'SVC', 'El Salvador colon', 0, 1),
(47, 'ERN', 'Eritrean nakfa', 0, 0),
(48, 'EEK', 'Estonian kroon', 0, 0),
(49, 'ETB', 'Ethiopian birr', 0, 1),
(50, 'EUR', 'EU euro', 1, 1),
(51, 'FKP', 'Falkland Islands pound', 0, 0),
(52, 'FJD', 'Fiji dollar', 0, 1),
(53, 'GMD', 'Gambian dalasi', 0, 1),
(54, 'GEL', 'Georgian lari', 0, 0),
(55, 'GHS', 'Ghanaian new cedi', 0, 0),
(56, 'GIP', 'Gibraltar pound', 0, 1),
(57, 'XAU', 'Gold (ounce)', 0, 0),
(58, 'XFO', 'Gold franc', 0, 0),
(59, 'GTQ', 'Guatemalan quetzal', 0, 1),
(60, 'GNF', 'Guinean franc', 0, 0),
(61, 'GYD', 'Guyana dollar', 0, 1),
(62, 'HTG', 'Haitian gourde', 0, 1),
(63, 'HNL', 'Honduran lempira', 0, 1),
(64, 'HKD', 'Hong Kong SAR dollar', 1, 1),
(65, 'HUF', 'Hungarian forint', 1, 1),
(66, 'ISK', 'Icelandic krona', 0, 0),
(67, 'XDR', 'IMF special drawing right', 0, 0),
(68, 'INR', 'Indian rupee', 1, 1),
(69, 'IDR', 'Indonesian rupiah', 0, 1),
(70, 'IRR', 'Iranian rial', 0, 0),
(71, 'IQD', 'Iraqi dinar', 0, 0),
(72, 'ILS', 'Israeli new shekel', 1, 1),
(73, 'JMD', 'Jamaican dollar', 0, 1),
(74, 'JPY', 'Japanese yen', 1, 0),
(75, 'JOD', 'Jordanian dinar', 0, 0),
(76, 'KZT', 'Kazakh tenge', 0, 1),
(77, 'KES', 'Kenyan shilling', 0, 1),
(78, 'KWD', 'Kuwaiti dinar', 0, 0),
(79, 'KGS', 'Kyrgyz som', 0, 1),
(80, 'LAK', 'Lao kip', 0, 1),
(81, 'LVL', 'Latvian lats', 0, 0),
(82, 'LBP', 'Lebanese pound', 0, 1),
(83, 'LSL', 'Lesotho loti', 0, 1),
(84, 'LRD', 'Liberian dollar', 0, 1),
(85, 'LYD', 'Libyan dinar', 0, 0),
(86, 'LTL', 'Lithuanian litas', 0, 0),
(87, 'MOP', 'Macao SAR pataca', 0, 1),
(88, 'MKD', 'Macedonian denar', 0, 1),
(89, 'MGA', 'Malagasy ariary', 0, 0),
(90, 'MWK', 'Malawi kwacha', 0, 1),
(91, 'MYR', 'Malaysian ringgit', 1, 1),
(92, 'MVR', 'Maldivian rufiyaa', 0, 1),
(93, 'MRO', 'Mauritanian ouguiya', 0, 0),
(94, 'MUR', 'Mauritius rupee', 0, 1),
(95, 'MXN', 'Mexican peso', 1, 1),
(96, 'MDL', 'Moldovan leu', 0, 1),
(97, 'MNT', 'Mongolian tugrik', 0, 1),
(98, 'MAD', 'Moroccan dirham', 0, 1),
(99, 'MZN', 'Mozambique new metical', 0, 0),
(100, 'MMK', 'Myanmar kyat', 0, 1),
(101, 'NAD', 'Namibian dollar', 0, 0),
(102, 'NPR', 'Nepalese rupee', 0, 1),
(103, 'ANG', 'Netherlands Antillian guilder', 0, 0),
(104, 'NZD', 'New Zealand dollar', 1, 1),
(105, 'NIO', 'Nicaraguan cordoba oro', 0, 1),
(106, 'NGN', 'Nigerian naira', 0, 0),
(107, 'KPW', 'North Korean won', 0, 0),
(108, 'NOK', 'Norwegian krone', 1, 1),
(109, 'OMR', 'Omani rial', 0, 0),
(110, 'PKR', 'Pakistani rupee', 0, 1),
(111, 'XPD', 'Palladium (ounce)', 0, 0),
(112, 'PAB', 'Panamanian balboa', 0, 0),
(113, 'PGK', 'Papua New Guinea kina', 0, 1),
(114, 'PYG', 'Paraguayan guarani', 0, 0),
(115, 'PEN', 'Peruvian nuevo sol', 0, 1),
(116, 'PHP', 'Philippine peso', 1, 1),
(117, 'XPT', 'Platinum (ounce)', 0, 0),
(118, 'PLN', 'Polish zloty', 1, 0),
(119, 'QAR', 'Qatari rial', 0, 1),
(120, 'RON', 'Romanian new leu', 0, 0),
(121, 'RUB', 'Russian ruble', 1, 1),
(122, 'RWF', 'Rwandan franc', 0, 0),
(123, 'SHP', 'Saint Helena pound', 0, 0),
(124, 'WST', 'Samoan tala', 0, 0),
(125, 'STD', 'Sao Tome and Principe dobra', 0, 0),
(126, 'SAR', 'Saudi riyal', 0, 1),
(127, 'RSD', 'Serbian dinar', 0, 0),
(128, 'SCR', 'Seychelles rupee', 0, 1),
(129, 'SLL', 'Sierra Leone leone', 0, 1),
(130, 'XAG', 'Silver (ounce)', 0, 0),
(131, 'SGD', 'Singapore dollar', 1, 1),
(132, 'SBD', 'Solomon Islands dollar', 0, 0),
(133, 'SOS', 'Somali shilling', 0, 1),
(134, 'ZAR', 'South African rand', 0, 1),
(135, 'KRW', 'South Korean won', 0, 0),
(136, 'LKR', 'Sri Lanka rupee', 0, 1),
(137, 'SDG', 'Sudanese pound', 0, 0),
(138, 'SRD', 'Suriname dollar', 0, 0),
(139, 'SZL', 'Swaziland lilangeni', 0, 1),
(140, 'SEK', 'Swedish krona', 1, 1),
(141, 'CHF', 'Swiss franc', 1, 1),
(142, 'SYP', 'Syrian pound', 0, 0),
(143, 'TWD', 'Taiwan New dollar', 1, 0),
(144, 'TJS', 'Tajik somoni', 0, 0),
(145, 'TZS', 'Tanzanian shilling', 0, 1),
(146, 'THB', 'Thai baht', 1, 1),
(147, 'TOP', 'Tongan paanga', 0, 0),
(148, 'TTD', 'Trinidad and Tobago dollar', 0, 1),
(149, 'TND', 'Tunisian dinar', 0, 0),
(150, 'TRY', 'Turkish lira', 0, 0),
(151, 'TMT', 'Turkmen new manat', 0, 0),
(152, 'AED', 'UAE dirham', 0, 0),
(153, 'UGX', 'Uganda new shilling', 0, 0),
(154, 'XFU', 'UIC franc', 0, 0),
(155, 'UAH', 'Ukrainian hryvnia', 0, 0),
(156, 'UYU', 'Uruguayan peso uruguayo', 0, 1),
(157, 'USD', 'US dollar', 1, 1),
(158, 'UZS', 'Uzbekistani sum', 0, 1),
(159, 'VUV', 'Vanuatu vatu', 0, 0),
(160, 'VEF', 'Venezuelan bolivar fuerte', 0, 0),
(161, 'VND', 'Vietnamese dong', 0, 0),
(162, 'YER', 'Yemeni rial', 0, 1),
(163, 'ZMK', 'Zambian kwacha', 0, 0),
(164, 'ZWL', 'Zimbabwe dollar', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `fcm`
--

CREATE TABLE `fcm` (
  `id` bigint(20) NOT NULL,
  `device` varchar(100) NOT NULL,
  `os_version` varchar(100) NOT NULL,
  `app_version` varchar(10) NOT NULL,
  `serial` varchar(100) NOT NULL,
  `regid` text NOT NULL,
  `created_at` bigint(20) NOT NULL,
  `last_update` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `fcm`
--

INSERT INTO `fcm` (`id`, `device`, `os_version`, `app_version`, `serial`, `regid`, `created_at`, `last_update`) VALUES
(4, 'Device Name', '6.0.1', '1.0', 'GGC00C0888E426A', 'APA91bEj7qmlVePXUpG4UjKOtyqG5x9hpeZ4tMhPDsJgDRWL76psPGtckLK3uMtmpLFj3RSFfgaVoBMCKhg5iR8RnPZPjeuml8Llgkc', 0, 0),
(7, 'sadasd', '1', '1', 'sad', 'sadasd', 1645142830603, 1645142830603);

-- --------------------------------------------------------

--
-- Table structure for table `news_info`
--

CREATE TABLE `news_info` (
  `id` bigint(20) NOT NULL,
  `title` varchar(100) NOT NULL,
  `brief_content` varchar(200) NOT NULL,
  `full_content` text NOT NULL,
  `image` varchar(110) NOT NULL,
  `draft` tinyint(1) NOT NULL,
  `status` varchar(50) NOT NULL,
  `created_at` bigint(20) NOT NULL,
  `last_update` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `news_info`
--

INSERT INTO `news_info` (`id`, `title`, `brief_content`, `full_content`, `image`, `draft`, `status`, `created_at`, `last_update`) VALUES
(12, 'Leaf-Curl-virus-Chilli', 'Pesticides for Leaf curl virus in Chilli', 'Pesticides for Leaf curl virus in Chilli', 'LeafCurlvirusChilli.png', 0, 'FEATURED', 1687085497761, 1689099089492),
(13, 'T.Stanes-Nimbecidin-Hero', 'T.Stanes-Nimbecidin-Hero', 'T.Stanes-Nimbecidin-Hero', 'TStanesNimbecidinHero.png', 0, 'FEATURED', 1687086008463, 1689099165658),
(14, 'Leaf-Blight-Tomato', 'Leaf-Blight-Tomato', 'Leaf-Blight-Tomato', 'LeafBlightTomato.png', 0, 'FEATURED', 1687086102777, 1689099213333);

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` bigint(20) NOT NULL,
  `name` varchar(100) NOT NULL,
  `image` varchar(110) NOT NULL,
  `price` decimal(12,2) NOT NULL,
  `price_discount` double NOT NULL DEFAULT 0,
  `stock` int(10) NOT NULL,
  `draft` tinyint(1) NOT NULL,
  `description` text NOT NULL,
  `status` varchar(50) NOT NULL,
  `created_at` bigint(20) NOT NULL,
  `last_update` bigint(20) NOT NULL,
  `weight` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `name`, `image`, `price`, `price_discount`, `stock`, `draft`, `description`, `status`, `created_at`, `last_update`, `weight`) VALUES
(141, 'Syngenta Saaho To 3251 Tomato Seeds', '1689099734959.jpg', 1380.00, 370, 1, 0, '<h2><span style=\"color: rgb(0, 0, 0); font-family: Roboto, sans-serif; font-size: 16px; letter-spacing: 0.4px;\">FEATURES:-&nbsp;</span></h2><ol><li><span style=\"color: rgb(0, 0, 0); font-family: Roboto, sans-serif; font-size: 16px; letter-spacing: 0.4px;\">Determinate Plant</span></li><li><span style=\"color: rgb(0, 0, 0); font-family: Roboto, sans-serif; font-size: 16px; letter-spacing: 0.4px;\">Good Stay greenness</span></li><li><span style=\"color: rgb(0, 0, 0); font-family: Roboto, sans-serif; font-size: 16px; letter-spacing: 0.4px;\">Dark green foliage</span></li><li><span style=\"color: rgb(0, 0, 0); font-family: Roboto, sans-serif; font-size: 16px; letter-spacing: 0.4px;\">Good Heat set</span></li><li><span style=\"color: rgb(0, 0, 0); font-family: Roboto, sans-serif; font-size: 16px; letter-spacing: 0.4px;\">Very Good Firm Fruits</span></li><li><span style=\"color: rgb(0, 0, 0); font-family: Roboto, sans-serif; font-size: 16px; letter-spacing: 0.4px;\">High Yield potential</span></li></ol><h2><span style=\"box-sizing: border-box; font-weight: 700; color: rgb(0, 0, 0); font-family: Roboto, sans-serif; font-size: 16px; letter-spacing: 0.4px;\">CHARACTERISTICS:-</span></h2><ol><li><span style=\"color: rgb(0, 0, 0); font-family: Roboto, sans-serif; font-size: 16px; letter-spacing: 0.4px;\">Yield- Average yield: 25-40 MT/acre ( depending on season and cultural practice)</span></li><li><span style=\"color: rgb(0, 0, 0); font-family: Roboto, sans-serif; font-size: 16px; letter-spacing: 0.4px;\">Size- Round Shape</span></li><li><span style=\"color: rgb(0, 0, 0); font-family: Roboto, sans-serif; font-size: 16px; letter-spacing: 0.4px;\">Shape- Flat Round type, uniform green</span></li><li><span style=\"color: rgb(0, 0, 0); font-family: Roboto, sans-serif; font-size: 16px; letter-spacing: 0.4px;\">Weight- 80-100g</span></li></ol><div class=\"table-wrapper\" style=\"box-sizing: border-box; max-width: 100%; overflow: auto; color: rgb(0, 0, 0); font-family: Roboto, sans-serif; font-size: 16px; letter-spacing: 0.4px;\"></div>', 'READY STOCK', 1687086279279, 1689099734959, ''),
(142, 'Corage Insecticide (Chlorantraniliprole 18.5% SC)', '1689099711326.png', 208.00, 0, 2, 0, '<pre><span style=\"color: rgb(0, 0, 0); font-family: Roboto, sans-serif; font-size: 16px; letter-spacing: 0.4px;\">ABOUT PRODUCT</span></pre><div><ul><li><span style=\"box-sizing: border-box; font-weight: 700; color: rgb(0, 0, 0); font-family: Roboto, sans-serif; font-size: 16px; letter-spacing: 0.4px;\"><span style=\"text-align: justify; font-weight: 400; letter-spacing: 0.4px;\">Coragen® insecticide is an anthranilic diamide Broad Spectrum insecticide in the form of a suspension concentrate.</span></span></li><li><span style=\"box-sizing: border-box; font-weight: 700; color: rgb(0, 0, 0); font-family: Roboto, sans-serif; font-size: 16px; letter-spacing: 0.4px;\"><span style=\"text-align: justify; font-weight: 400; letter-spacing: 0.4px;\">Coragen® insecticide is particularly active on Lepidopteran insect pests, primarily as a larvicide.</span></span></li><li><span style=\"box-sizing: border-box; font-weight: 700; color: rgb(0, 0, 0); font-family: Roboto, sans-serif; font-size: 16px; letter-spacing: 0.4px;\"><span style=\"text-align: justify; font-weight: 400; letter-spacing: 0.4px;\">Coragen® insecticide is powered by active ingredient Rynaxypyr® active which has a unique mode of action that controls pests resistant to other insecticides.</span></span></li><li><span style=\"box-sizing: border-box; font-weight: 700; color: rgb(0, 0, 0); font-family: Roboto, sans-serif; font-size: 16px; letter-spacing: 0.4px;\"><span style=\"text-align: justify; font-weight: 400; letter-spacing: 0.4px;\">Coragen® insecticide is selective &amp; safe for non-target arthropods and conserves natural parasitoids, predators and pollinators.</span></span></li></ul></div>', 'READY STOCK', 1687087983022, 1689099711326, ''),
(143, 'UPL Phoskill Insecticide (Monocrotophos 36% SL)', '1689099675380.png', 175.00, 0, 4, 0, '<h2><span style=\"box-sizing: border-box; font-weight: 700; color: rgb(0, 0, 0); font-family: Roboto, sans-serif; font-size: 16px; letter-spacing: 0.4px;\">ABOUT PRODUCT</span></h2><pre><ul style=\"box-sizing: border-box; margin: 0px 0px 0px 30px; padding: 0px; text-rendering: optimizelegibility; color: rgb(0, 0, 0); font-family: Roboto, sans-serif; font-size: 16px; letter-spacing: 0.4px;\"><li style=\"text-align: justify; box-sizing: border-box; margin-bottom: 0px;\">Highly effective broad spectrum solution for management of various sucking and chewing pests in Agriculture.</li></ul></pre>', 'READY STOCK', 1687088340885, 1689099675380, ''),
(144, 'Multiplex Trishul (VAM) Bio Fertilizer', '1689099650016.jpg', 399.00, 0, 1, 0, '<h2 style=\"text-align: justify;\"><span style=\"box-sizing: border-box; font-weight: 700; color: rgb(0, 0, 0); font-family: Roboto, sans-serif; font-size: 16px; letter-spacing: 0.4px;\">Multiplex Trishul (VAM)</span><span style=\"color: rgb(0, 0, 0); font-family: Roboto, sans-serif; font-size: 16px; letter-spacing: 0.4px;\">&nbsp;</span><span style=\"box-sizing: border-box; font-weight: 700; color: rgb(0, 0, 0); font-family: Roboto, sans-serif; font-size: 16px; letter-spacing: 0.4px;\">Vesicular Arbuscular Mycorrhizae</span></h2><h3 style=\"text-align: justify;\"><span style=\"box-sizing: border-box; font-weight: 700; color: rgb(0, 0, 0); font-family: Roboto, sans-serif; font-size: 16px; letter-spacing: 0.4px;\"><span style=\"box-sizing: border-box; letter-spacing: 0.4px;\">Specifications:</span></span></h3><div><span style=\"box-sizing: border-box; color: rgb(0, 0, 0); font-family: Roboto, sans-serif; font-size: 16px; letter-spacing: 0.4px;\"><span style=\"box-sizing: border-box; letter-spacing: 0.4px;\"><p style=\"\"></p><ul style=\"font-weight: 400; box-sizing: border-box; margin: 0px 0px 25px 30px; padding: 0px; text-rendering: optimizelegibility; letter-spacing: 0.4px;\"><li style=\"text-align: justify; box-sizing: border-box; margin-bottom: 0px;\"><em style=\"box-sizing: border-box;\">Multiplex Trishul</em>&nbsp;contains Vesicular Arbuscular Mycorrhizae (VAM), which is symbiotic association with root system helps in better absorption of phosphorous, water and other essential plant nutrients in easily usable organic form.</li></ul><ul style=\"font-weight: 400; box-sizing: border-box; margin: 0px 0px 25px 30px; padding: 0px; text-rendering: optimizelegibility; letter-spacing: 0.4px;\"><li style=\"text-align: justify; box-sizing: border-box; margin-bottom: 0px;\">It produces a wide range of plant growth-promoting substances like IAA, IBA, GA. which helps in the healthy growth of plants.</li></ul><h3 style=\"text-align: justify;\"><span style=\"box-sizing: border-box; font-weight: 700; letter-spacing: 0.4px; text-align: start;\">Dosage / Acre:</span></h3><p></p><p style=\"text-align: justify; box-sizing: border-box; margin: 0px 0px 25px; letter-spacing: 0.4px;\">Mix @ 1 ltr of&nbsp;<span style=\"box-sizing: border-box; text-decoration-line: underline;\">Multiplex Trishul</span>&nbsp;with 100 kg of well-decomposed farmyard manure or Multiplex Annapurna and broadcast before sowing or transplanting crops.</p><div><span style=\"box-sizing: border-box; font-weight: 700; letter-spacing: 0.4px;\"><p style=\"text-align: justify; box-sizing: border-box; margin: 0px 0px 25px; font-weight: 400; letter-spacing: 0.4px;\"><span style=\"box-sizing: border-box;\">Mix @&nbsp;</span><span style=\"box-sizing: border-box;\">1</span><span style=\"box-sizing: border-box;\">&nbsp;ltr of Multiplex Trishul 200 liters of water and provide to one acre of land in the drip irrigation.</span></p></span></div></span></span></div>', 'READY STOCK', 1687088534292, 1689099650016, ''),
(145, 'Pioneer Agro bio NPK Fertilizer', '1689099399621.png', 1009.00, 0, 1, 0, '<p></p><ul style=\"box-sizing: border-box; margin: 0px 0px 0px 30px; padding: 0px; text-rendering: optimizelegibility; color: rgb(0, 0, 0); font-family: Roboto, sans-serif; font-size: 16px; letter-spacing: 0.4px;\"><li style=\"text-align: justify; box-sizing: border-box; margin-bottom: 0px;\">Bio NPK is a Bacterial Consortium Which is able to fix Atmospheric Nitrogen, Solubilize phosphate and mobilize potash, Zinc and Silica into Available Form, There by supplementing balance nutrition to the crops.</li></ul><ul style=\"box-sizing: border-box; margin: 0px 0px 0px 30px; padding: 0px; text-rendering: optimizelegibility; color: rgb(0, 0, 0); font-family: Roboto, sans-serif; font-size: 16px; letter-spacing: 0.4px;\"><li style=\"text-align: justify; box-sizing: border-box; margin-bottom: 0px;\">It converts non-available forms of some tightly bonded micro nutrients into available form Microbial Consortium.</li></ul><div style=\"text-align: justify;\"><font color=\"#000000\" face=\"Roboto, sans-serif\"><span style=\"font-size: 16px; letter-spacing: 0.4px;\"><br></span></font></div><h3 style=\"text-align: justify;\"><font color=\"#000000\" face=\"Roboto, sans-serif\"><span style=\"font-size: 16px; letter-spacing: 0.4px;\">Dosage:-</span></font></h3><p></p><p><span style=\"color: rgb(0, 0, 0); font-family: Roboto, sans-serif; font-size: 16px; letter-spacing: 0.4px;\">2 litre/acre.</span><br></p><p></p><div style=\"text-align: justify;\"><font color=\"#000000\" face=\"Roboto, sans-serif\"><span style=\"font-size: 16px; letter-spacing: 0.4px;\"><br></span></font></div><p></p><div></div><h2 style=\"text-align: justify;\"></h2><p></p><div><span style=\"box-sizing: border-box; color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: 15px; letter-spacing: 0.4px; text-align: center; text-transform: capitalize; background-color: rgb(32, 94, 52);\"><b><br></b></span></div><div><span style=\"box-sizing: border-box; color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: 15px; letter-spacing: 0.4px; text-align: center; text-transform: capitalize; background-color: rgb(32, 94, 52);\"><b><br></b></span></div><div><span style=\"box-sizing: border-box; color: rgb(255, 255, 255); font-family: Roboto, sans-serif; font-size: 15px; letter-spacing: 0.4px; text-align: center; text-transform: capitalize; background-color: rgb(32, 94, 52);\"><b><br></b></span></div><p></p>', 'READY STOCK', 1687088813920, 1689099399621, ''),
(146, 'VNR 212 F1 Hybrid Brinjal Seed, Oblong Shaped And High Yielder', '1689099359650.png', 135.00, 0, 4, 0, '<h3><span style=\"font-family: inherit; font-size: 14px;\">Description:-</span><br></h3><div><p></p><ul><li><span style=\"text-align: justify; color: rgb(0, 0, 0); font-family: Roboto, sans-serif; font-size: 16px; letter-spacing: 0.4px;\">VNR 212 is an early hybrid and high yielder</span></li><li><span style=\"text-align: justify; color: rgb(0, 0, 0); font-family: Roboto, sans-serif; font-size: 16px; letter-spacing: 0.4px;\">Cluster bearing and continuous fruiting</span></li><li><span style=\"text-align: justify; color: rgb(0, 0, 0); font-family: Roboto, sans-serif; font-size: 16px; letter-spacing: 0.4px;\">Fetches good market price due to its attractive fruit color and shine</span></li></ul><h3 style=\"text-align: justify;\"><font color=\"#000000\" face=\"Roboto, sans-serif\"><span style=\"font-size: 16px; letter-spacing: 0.4px;\">Usage:-</span></font></h3><div><h3><p></p><ul style=\"box-sizing: border-box; margin: 0px 0px 25px 30px; padding: 0px; text-rendering: optimizelegibility; color: rgb(0, 0, 0); font-family: Roboto, sans-serif; font-size: 16px; letter-spacing: 0.4px;\"><li style=\"text-align: justify; box-sizing: border-box; margin-bottom: 0px;\"><span style=\"box-sizing: border-box; font-weight: 700;\">FRUIT COLOR</span>: <span style=\"font-weight: normal;\">Dark Violet.</span></li></ul><p></p><p></p><ul style=\"box-sizing: border-box; margin: 0px 0px 25px 30px; padding: 0px; text-rendering: optimizelegibility; color: rgb(0, 0, 0); font-family: Roboto, sans-serif; font-size: 16px; letter-spacing: 0.4px;\"><li style=\"text-align: justify; box-sizing: border-box; margin-bottom: 0px;\"><span style=\"box-sizing: border-box; font-weight: 700;\">FRUIT SHAPE</span>: <span style=\"font-weight: normal;\">Oblong</span></li></ul><p></p><p></p><ul style=\"box-sizing: border-box; margin: 0px 0px 25px 30px; padding: 0px; text-rendering: optimizelegibility; color: rgb(0, 0, 0); font-family: Roboto, sans-serif; font-size: 16px; letter-spacing: 0.4px;\"><li style=\"text-align: justify; box-sizing: border-box; margin-bottom: 0px;\"><span style=\"box-sizing: border-box; font-weight: 700;\">FRUIT SIZE</span>: <span style=\"font-weight: normal;\">Length 9.5-10.5 cms, Width 4.5-5.5cm</span></li></ul><p></p><p></p><ul style=\"box-sizing: border-box; margin: 0px 0px 25px 30px; padding: 0px; text-rendering: optimizelegibility; color: rgb(0, 0, 0); font-family: Roboto, sans-serif; font-size: 16px; letter-spacing: 0.4px;\"><li style=\"text-align: justify; box-sizing: border-box; margin-bottom: 0px;\"><span style=\"box-sizing: border-box; font-weight: 700;\">FRUIT WEIGHT</span>&nbsp;: <span style=\"font-weight: normal;\">100 - 150gm</span></li></ul><p></p><ul style=\"box-sizing: border-box; margin: 0px 0px 25px 30px; padding: 0px; text-rendering: optimizelegibility; color: rgb(0, 0, 0); font-family: Roboto, sans-serif; font-size: 16px; letter-spacing: 0.4px;\"><li style=\"text-align: justify; box-sizing: border-box; margin-bottom: 0px;\"><span style=\"box-sizing: border-box; font-weight: 700;\">MATURITY</span></li></ul><div style=\"text-align: justify;\"><table style=\"width: 580px; border-spacing: 1px; position: relative; border: 1px solid rgb(179, 173, 173); background: var(--colorBorder); border-collapse: collapse; padding: 5px; margin-bottom: 0px; table-layout: fixed; color: rgb(0, 0, 0); font-family: Roboto, sans-serif; font-size: 16px; font-weight: 400; letter-spacing: 0.4px; text-align: start;\"><tbody style=\"box-sizing: border-box;\"><tr style=\"box-sizing: border-box;\"><th style=\"box-sizing: border-box; border: 1px solid rgb(179, 173, 173); text-align: left; padding: 5px; background: rgb(240, 240, 240); color: rgb(49, 48, 48);\"><p style=\"text-align: justify;\">SOWING PERIOD</p></th><th style=\"box-sizing: border-box; border: 1px solid rgb(179, 173, 173); text-align: left; padding: 5px; background: rgb(240, 240, 240); color: rgb(49, 48, 48);\"><p style=\"text-align: justify;\">JUNE- OCTOBER</p></th></tr><tr style=\"box-sizing: border-box;\"><td style=\"box-sizing: border-box; border: 1px solid rgb(179, 173, 173); padding: 5px; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; color: rgb(49, 48, 48);\"><p style=\"text-align: justify;\">&nbsp;Seed Qty/ Acre</p></td><td style=\"box-sizing: border-box; border: 1px solid rgb(179, 173, 173); padding: 5px; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; color: rgb(49, 48, 48);\"><p style=\"text-align: justify;\">&nbsp;60 - 80gms</p></td></tr><tr style=\"box-sizing: border-box;\"><td style=\"box-sizing: border-box; border: 1px solid rgb(179, 173, 173); padding: 5px; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; color: rgb(49, 48, 48);\"><p style=\"text-align: justify;\">Sowing Distance between row &amp; Ridges&nbsp;</p></td><td style=\"box-sizing: border-box; border: 1px solid rgb(179, 173, 173); padding: 5px; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; color: rgb(49, 48, 48);\"><p style=\"text-align: justify;\">3 - 5 Feet</p></td></tr><tr style=\"box-sizing: border-box;\"><td style=\"box-sizing: border-box; border: 1px solid rgb(179, 173, 173); padding: 5px; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; color: rgb(49, 48, 48);\"><p style=\"text-align: justify;\">&nbsp;Sowing Distance between plants</p></td><td style=\"box-sizing: border-box; border: 1px solid rgb(179, 173, 173); padding: 5px; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; color: rgb(49, 48, 48);\"><p style=\"text-align: justify;\">2 - 3 Feet&nbsp;</p></td></tr><tr style=\"box-sizing: border-box;\"><td style=\"box-sizing: border-box; border: 1px solid rgb(179, 173, 173); padding: 5px; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; color: rgb(49, 48, 48);\"><p style=\"text-align: justify;\">Sowing Period&nbsp;</p></td><td style=\"box-sizing: border-box; border: 1px solid rgb(179, 173, 173); padding: 5px; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; color: rgb(49, 48, 48);\"><p style=\"text-align: justify;\">&nbsp;June - October</p></td></tr><tr style=\"box-sizing: border-box;\"><td style=\"box-sizing: border-box; border: 1px solid rgb(179, 173, 173); padding: 5px; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; color: rgb(49, 48, 48);\"><p style=\"text-align: justify;\">&nbsp;First Harvest</p></td><td style=\"box-sizing: border-box; border: 1px solid rgb(179, 173, 173); padding: 5px; background-image: initial; background-position: initial; background-size: initial; background-repeat: initial; background-attachment: initial; background-origin: initial; background-clip: initial; color: rgb(49, 48, 48);\"><p style=\"text-align: justify;\">&nbsp;42- 45days</p></td></tr></tbody></table></div></h3></div><p></p></div>', 'READY STOCK', 1687089065817, 1689099359650, ''),
(147, 'NS 1101 Chilli Seed', '1689099330001.png', 429.00, 0, 1, 0, '<p></p><p></p><ul><li><span style=\"text-align: justify; color: rgb(0, 0, 0); font-family: Roboto, sans-serif; font-size: 16px; letter-spacing: 0.4px;\">Plant Habit: Medium tall spreading plant</span></li></ul><ul><li><span style=\"text-align: justify; color: rgb(0, 0, 0); font-family: Roboto, sans-serif; font-size: 16px; letter-spacing: 0.4px;\">Usage : green fresh &amp; red dry</span></li></ul><ul><li><span style=\"text-align: justify; color: rgb(0, 0, 0); font-family: Roboto, sans-serif; font-size: 16px; letter-spacing: 0.4px;\">Maturity:70-75</span></li></ul><ul><li><span style=\"text-align: justify; color: rgb(0, 0, 0); font-family: Roboto, sans-serif; font-size: 16px; letter-spacing: 0.4px;\">immature fruit colour : Dark green</span></li></ul><ul><li><span style=\"text-align: justify; color: rgb(0, 0, 0); font-family: Roboto, sans-serif; font-size: 16px; letter-spacing: 0.4px;\">mature fruit colour : Dark red</span></li></ul><ul><li><span style=\"text-align: justify; color: rgb(0, 0, 0); font-family: Roboto, sans-serif; font-size: 16px; letter-spacing: 0.4px;\">Fruit Length(cm):8-10</span></li></ul><ul><li><span style=\"text-align: justify; color: rgb(0, 0, 0); font-family: Roboto, sans-serif; font-size: 16px; letter-spacing: 0.4px;\">Fruit width(cm):1.o-1.1</span></li></ul><ul><li><span style=\"text-align: justify; color: rgb(0, 0, 0); font-family: Roboto, sans-serif; font-size: 16px; letter-spacing: 0.4px;\">Pericap thickness: Medium thick</span></li></ul><ul><li><span style=\"text-align: justify; color: rgb(0, 0, 0); font-family: Roboto, sans-serif; font-size: 16px; letter-spacing: 0.4px;\">Pungency: very high(60000 SHU)</span></li></ul><p></p><p></p>', 'READY STOCK', 1687089354734, 1689099330001, ''),
(148, 'Abhishek Bitter Gourd Seed', '1689099295190.png', 599.00, 0, 2, 0, '<h3 style=\"text-align: justify; box-sizing: border-box; margin: 0px 0px 25px; color: rgb(0, 0, 0); font-family: Roboto, sans-serif; font-size: 16px; letter-spacing: 0.4px;\"><span style=\"box-sizing: border-box; font-weight: 700;\">More Yield Per Picking</span></h3><p style=\"box-sizing: border-box; margin: 0px 0px 25px; color: rgb(0, 0, 0); font-family: Roboto, sans-serif; font-size: 16px; letter-spacing: 0.4px;\"><span style=\"box-sizing: border-box;\"></span></p><p style=\"text-align: justify; box-sizing: border-box; margin: 0px 0px 25px; color: rgb(0, 0, 0); font-family: Roboto, sans-serif; font-size: 16px; letter-spacing: 0.4px;\"></p><ul><li><span style=\"box-sizing: border-box;\">♦ Plant Vigour : Very high</span></li><li><span style=\"box-sizing: border-box;\">♦ Fruit Colour : Dark green</span></li><li><span style=\"box-sizing: border-box;\">♦&nbsp;</span><span style=\"box-sizing: border-box;\">Fruit Length : 20-26 cm</span></li><li><span style=\"box-sizing: border-box;\">♦ Average Fruit Weight : 110-120 g</span></li><li><span style=\"box-sizing: border-box;\">♦ Fruit Girth : 3.5-4 cm</span></li><li><span style=\"box-sizing: border-box;\">♦ Fruit Shape : Spindle, thick, medium long</span></li><li><span style=\"box-sizing: border-box;\">♦ Picking : 50 to 60 days</span></li><li><span style=\"box-sizing: border-box;\">♦ Crop Duration : 110-120 days</span></li><li><span style=\"box-sizing: border-box;\">♦ Presence of Prickle : Yes, sharp</span></li><li><span style=\"box-sizing: border-box;\">♦ Intensity of Prickle : More</span></li></ul><p></p><div style=\"text-align: justify;\"><span style=\"box-sizing: border-box; font-weight: 700; color: rgb(0, 0, 0); font-family: Roboto, sans-serif; font-size: 16px; letter-spacing: 0.4px;\">Soil</span><span style=\"color: rgb(0, 0, 0); font-family: Roboto, sans-serif; font-size: 16px; letter-spacing: 0.4px;\">&nbsp;: Well drained sandy loams and clay loam soil is ideal for the crop.</span></div><span style=\"box-sizing: border-box; font-weight: 700; color: rgb(0, 0, 0); font-family: Roboto, sans-serif; font-size: 16px; letter-spacing: 0.4px;\"><div style=\"text-align: justify;\"><span style=\"box-sizing: border-box; letter-spacing: 0.4px;\">Sowing time</span><span style=\"letter-spacing: 0.4px;\">&nbsp;: Rainy and Summer</span></div></span><span style=\"box-sizing: border-box; font-weight: 700; color: rgb(0, 0, 0); font-family: Roboto, sans-serif; font-size: 16px; letter-spacing: 0.4px;\"><div style=\"text-align: justify;\"><span style=\"box-sizing: border-box; letter-spacing: 0.4px;\">Optimum temp. for germination</span><span style=\"letter-spacing: 0.4px;\">&nbsp;: 28 - 320C</span></div></span><span style=\"box-sizing: border-box; font-weight: 700; color: rgb(0, 0, 0); font-family: Roboto, sans-serif; font-size: 16px; letter-spacing: 0.4px;\"><div style=\"text-align: justify;\"><span style=\"box-sizing: border-box; letter-spacing: 0.4px;\">Spacing : Row to Row</span><span style=\"letter-spacing: 0.4px;\">&nbsp;: 120cm, Plant to Plant : 45cm</span></div></span><span style=\"box-sizing: border-box; font-weight: 700; color: rgb(0, 0, 0); font-family: Roboto, sans-serif; font-size: 16px; letter-spacing: 0.4px;\"><div style=\"text-align: justify;\"><span style=\"box-sizing: border-box; letter-spacing: 0.4px;\">Seed rate</span><span style=\"letter-spacing: 0.4px;\">&nbsp;: 600 - 700 gm / acre.</span></div></span><span style=\"box-sizing: border-box; font-weight: 700; color: rgb(0, 0, 0); font-family: Roboto, sans-serif; font-size: 16px; letter-spacing: 0.4px;\"><div style=\"text-align: justify;\"><span style=\"box-sizing: border-box; letter-spacing: 0.4px;\">Preparation of Main field</span><span style=\"letter-spacing: 0.4px;\">&nbsp;: Deep ploughing and harrowing.</span><span style=\"box-sizing: border-box; letter-spacing: 0.4px; line-height: 1.4;\">● Add well decomposed FYM 7-</span><span style=\"letter-spacing: 0.4px;\">8 tones per acre ● Open ridges &amp; furrows at required spacing (Apply basal dose of fertilizer as recommended) ● Irrigate the field one day before sowing</span></div></span><p></p><span style=\"box-sizing: border-box;\"></span><p></p><p style=\"text-align: justify; box-sizing: border-box; margin: 0px 0px 25px; color: rgb(0, 0, 0); font-family: Roboto, sans-serif; font-size: 16px; letter-spacing: 0.4px;\"><span style=\"box-sizing: border-box;\"></span></p><p style=\"text-align: justify; box-sizing: border-box; margin: 0px 0px 25px; color: rgb(0, 0, 0); font-family: Roboto, sans-serif; font-size: 16px; letter-spacing: 0.4px;\"><span style=\"box-sizing: border-box;\"></span></p><p style=\"text-align: justify; box-sizing: border-box; margin: 0px 0px 25px; color: rgb(0, 0, 0); font-family: Roboto, sans-serif; font-size: 16px; letter-spacing: 0.4px;\"><span style=\"box-sizing: border-box;\"></span><span style=\"box-sizing: border-box;\"></span></p><p style=\"text-align: justify; box-sizing: border-box; margin: 0px 0px 25px; color: rgb(0, 0, 0); font-family: Roboto, sans-serif; font-size: 16px; letter-spacing: 0.4px;\"><span style=\"box-sizing: border-box;\"></span></p><p style=\"text-align: justify; box-sizing: border-box; margin: 0px 0px 25px; color: rgb(0, 0, 0); font-family: Roboto, sans-serif; font-size: 16px; letter-spacing: 0.4px;\"><span style=\"box-sizing: border-box;\"></span></p>', 'OUT OF STOCK', 1687089543852, 1689099295190, ''),
(149, 'Kaveri Bottle Gourd Seed 250 Grams', '1689099257220.png', 175.00, 0, 1, 0, '<p style=\"text-align: justify;\"><span style=\"color: rgb(0, 0, 0); font-family: Roboto, sans-serif; font-size: 16px; letter-spacing: 0.4px;\">Vigorous plants with continuous fruit bearing habit. Fruits are cylindrical (25-30cm), each weighing 300-350g. The rind is smooth with uniform green colour. Flesh is white with slow seed maturity. It is a heavy yielder.</span></p><p style=\"text-align: justify;\"><span style=\"color: rgb(0, 0, 0); font-family: Roboto, sans-serif; font-size: 16px; letter-spacing: 0.4px;\"><br></span></p><p></p><ul style=\"box-sizing: border-box; margin: 0px 0px 25px 30px; padding: 0px; text-rendering: optimizelegibility; color: rgb(0, 0, 0); font-family: Roboto, sans-serif; font-size: 16px; letter-spacing: 0.4px;\"><li style=\"text-align: justify; box-sizing: border-box; margin-bottom: 0px;\"><span style=\"box-sizing: border-box; font-weight: 700;\">Hybrid type:</span>&nbsp;Medium Long Cylindrical</li></ul><ul style=\"box-sizing: border-box; margin: 0px 0px 25px 30px; padding: 0px; text-rendering: optimizelegibility; color: rgb(0, 0, 0); font-family: Roboto, sans-serif; font-size: 16px; letter-spacing: 0.4px;\"><li style=\"text-align: justify; box-sizing: border-box; margin-bottom: 0px;\"><span style=\"box-sizing: border-box; font-weight: 700;\">Relative days to maturity (DS):</span>&nbsp;45-50</li></ul><ul style=\"box-sizing: border-box; margin: 0px 0px 25px 30px; padding: 0px; text-rendering: optimizelegibility; color: rgb(0, 0, 0); font-family: Roboto, sans-serif; font-size: 16px; letter-spacing: 0.4px;\"><li style=\"text-align: justify; box-sizing: border-box; margin-bottom: 0px;\"><span style=\"box-sizing: border-box; font-weight: 700;\">Fruit shape</span>: cylindrical</li></ul><ul style=\"box-sizing: border-box; margin: 0px 0px 25px 30px; padding: 0px; text-rendering: optimizelegibility; color: rgb(0, 0, 0); font-family: Roboto, sans-serif; font-size: 16px; letter-spacing: 0.4px;\"><li style=\"text-align: justify; box-sizing: border-box; margin-bottom: 0px;\"><span style=\"box-sizing: border-box; font-weight: 700;\">Fruit length (cm)</span>: 25-30</li></ul><ul style=\"box-sizing: border-box; margin: 0px 0px 25px 30px; padding: 0px; text-rendering: optimizelegibility;\"><li style=\"color: rgb(0, 0, 0); font-family: Roboto, sans-serif; font-size: 16px; letter-spacing: 0.4px; text-align: justify; box-sizing: border-box; margin-bottom: 0px;\"><span style=\"box-sizing: border-box; font-weight: 700;\">Fruit weight (g):</span>&nbsp;300-350&nbsp;</li><li style=\"color: rgb(0, 0, 0); font-family: Roboto, sans-serif; font-size: 16px; letter-spacing: 0.4px; text-align: justify; box-sizing: border-box; margin-bottom: 0px;\">Packet Weight (g): 299 Grams</li></ul><ul style=\"box-sizing: border-box; margin: 0px 0px 25px 30px; padding: 0px; text-rendering: optimizelegibility; color: rgb(0, 0, 0); font-family: Roboto, sans-serif; font-size: 16px; letter-spacing: 0.4px;\"><li style=\"text-align: justify; box-sizing: border-box; margin-bottom: 0px;\"><span style=\"box-sizing: border-box; font-weight: 700;\">Fruit colour:</span>&nbsp;light green</li></ul><ul style=\"box-sizing: border-box; margin: 0px 0px 25px 30px; padding: 0px; text-rendering: optimizelegibility; color: rgb(0, 0, 0); font-family: Roboto, sans-serif; font-size: 16px; letter-spacing: 0.4px;\"><li style=\"text-align: justify; box-sizing: border-box; margin-bottom: 0px;\"><span style=\"box-sizing: border-box; font-weight: 700;\">Remarks:</span>&nbsp;slow seed maturity</li></ul><ul style=\"box-sizing: border-box; margin: 0px 0px 25px 30px; padding: 0px; text-rendering: optimizelegibility; color: rgb(0, 0, 0); font-family: Roboto, sans-serif; font-size: 16px; letter-spacing: 0.4px;\"><li style=\"text-align: justify; box-sizing: border-box; margin-bottom: 0px;\"><span style=\"box-sizing: border-box; font-weight: 700;\">Recommended for:</span>&nbsp;India, South East Asia</li></ul><p></p>', 'READY STOCK', 1687089753393, 1691738433005, '250 Grams');

-- --------------------------------------------------------

--
-- Table structure for table `product_category`
--

CREATE TABLE `product_category` (
  `product_id` bigint(20) NOT NULL,
  `category_id` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product_category`
--

INSERT INTO `product_category` (`product_id`, `category_id`) VALUES
(148, 16),
(147, 16),
(146, 16),
(145, 17),
(144, 17),
(143, 18),
(142, 18),
(141, 16),
(149, 16);

-- --------------------------------------------------------

--
-- Table structure for table `product_image`
--

CREATE TABLE `product_image` (
  `product_id` bigint(20) NOT NULL,
  `name` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product_image`
--

INSERT INTO `product_image` (`product_id`, `name`) VALUES
(141, '0_1687086750021.jpg'),
(141, '1_1687086752321.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `product_order`
--

CREATE TABLE `product_order` (
  `id` bigint(20) NOT NULL,
  `code` varchar(20) NOT NULL,
  `buyer` varchar(50) NOT NULL,
  `address` varchar(300) NOT NULL,
  `email` varchar(50) NOT NULL,
  `shipping` varchar(20) NOT NULL,
  `shipping_location` varchar(50) NOT NULL,
  `shipping_rate` decimal(12,2) NOT NULL DEFAULT 0.00,
  `date_ship` bigint(20) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `comment` text NOT NULL,
  `status` varchar(50) NOT NULL,
  `payment` varchar(50) NOT NULL,
  `payment_status` varchar(20) NOT NULL,
  `payment_data` text NOT NULL,
  `total_fees` decimal(12,2) NOT NULL,
  `tax` decimal(12,2) NOT NULL,
  `serial` varchar(100) DEFAULT NULL,
  `created_at` bigint(20) NOT NULL,
  `last_update` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product_order`
--

INSERT INTO `product_order` (`id`, `code`, `buyer`, `address`, `email`, `shipping`, `shipping_location`, `shipping_rate`, `date_ship`, `phone`, `comment`, `status`, `payment`, `payment_status`, `payment_data`, `total_fees`, `tax`, `serial`, `created_at`, `last_update`, `user_id`) VALUES
(19, 'CV07510KD', 'Amol Rathod', 'Pune', 'amol@gmail.com', '', '', 0.00, 1691560235696, '9130255918', '', 'WAITING', '', '', '', 859.14, 11.00, 'cab8c1a4e4421a3b', 1691560235696, 1691560235696, 2),
(20, 'VV00104EU', 'amol Rathod ', 'pune', 'amol@gmail.com', '', '', 0.00, 1691561152194, '9130255918', '', 'CANCEL', 'RAZORPAY', '', 'order_MNrg4tSdwL3veF', 859.14, 11.00, 'cab8c1a4e4421a3b', 1691561152193, 1691561152194, 2),
(21, 'JR77732PT', 'Deepak Tarfe', 'hingoli ', 'dipaktarfe2@gmail.com', '', '', 0.00, 1693368834781, '9130255918', '', 'WAITING', 'RAZORPAY', '', 'order_MW8zjFmh0JMMBZ', 664.89, 11.00, 'cab8c1a4e4421a3b', 1693368834781, 1693368834781, 1);

-- --------------------------------------------------------

--
-- Table structure for table `product_order_detail`
--

CREATE TABLE `product_order_detail` (
  `id` bigint(20) NOT NULL,
  `order_id` bigint(20) NOT NULL,
  `product_id` bigint(20) NOT NULL,
  `product_name` varchar(100) NOT NULL,
  `amount` int(11) NOT NULL,
  `price_item` decimal(12,2) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `last_update` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_id` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product_order_detail`
--

INSERT INTO `product_order_detail` (`id`, `order_id`, `product_id`, `product_name`, `amount`, `price_item`, `created_at`, `last_update`, `user_id`) VALUES
(15, 19, 148, 'Abhishek Bitter Gourd Seed', 1, 599.00, '2023-08-09 05:50:38', '0000-00-00 00:00:00', 2),
(16, 19, 149, 'Kaveri Bottle Gourd Seed', 1, 175.00, '2023-08-09 05:50:38', '0000-00-00 00:00:00', 2),
(17, 20, 148, 'Abhishek Bitter Gourd Seed', 1, 599.00, '2023-08-09 06:05:54', '0000-00-00 00:00:00', 2),
(18, 20, 149, 'Kaveri Bottle Gourd Seed', 1, 175.00, '2023-08-09 06:05:54', '0000-00-00 00:00:00', 2),
(19, 21, 148, 'Abhishek Bitter Gourd Seed', 1, 599.00, '2023-08-30 04:13:57', '0000-00-00 00:00:00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `shipping`
--

CREATE TABLE `shipping` (
  `id` bigint(20) NOT NULL,
  `location` varchar(50) NOT NULL,
  `location_id` varchar(50) NOT NULL,
  `rate_economy` decimal(12,2) NOT NULL,
  `rate_regular` decimal(12,2) NOT NULL,
  `rate_express` decimal(12,2) NOT NULL,
  `active` tinyint(1) NOT NULL,
  `active_eco` tinyint(1) NOT NULL,
  `active_reg` tinyint(1) NOT NULL,
  `active_exp` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `shipping`
--

INSERT INTO `shipping` (`id`, `location`, `location_id`, `rate_economy`, `rate_regular`, `rate_express`, `active`, `active_eco`, `active_reg`, `active_exp`) VALUES
(100, 'INDIA', '', 5.00, 10.00, 20.00, 0, 1, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` bigint(11) NOT NULL,
  `name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `username` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `email` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `password` text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `name`, `username`, `email`, `password`) VALUES
(1, 'Dipak Tarfe', 'admin', 'dipaktarfe2@gmail.com', 'f91e15dbec69fc40f81f0876e7009648');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `name` text NOT NULL,
  `password` text NOT NULL,
  `email` varchar(300) NOT NULL,
  `phone` text NOT NULL,
  `reset_password_otp` varchar(50) NOT NULL,
  `reset_password_created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `profile_image` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `name`, `password`, `email`, `phone`, `reset_password_otp`, `reset_password_created_at`, `profile_image`) VALUES
(1, 'Deepak Tarfe', 'Pass@1234', 'dipak@gmail.com', '9130255918', '317225', '2023-08-11 06:47:20', ''),
(2, 'Amol Rathod', 'Pass@123', 'amol@gmail.com', '9021641429', '000000', '2023-07-11 18:07:34', ''),
(3, 'Krushna Tarfe', 'Pass@123', 'krushna@gmail.com', '9021641429', '000000', '2023-07-18 11:46:47', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `app_version`
--
ALTER TABLE `app_version`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique` (`name`);

--
-- Indexes for table `config`
--
ALTER TABLE `config`
  ADD PRIMARY KEY (`code`);

--
-- Indexes for table `currency`
--
ALTER TABLE `currency`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `fcm`
--
ALTER TABLE `fcm`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `news_info`
--
ALTER TABLE `news_info`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `product_unique_name` (`name`);
ALTER TABLE `product` ADD FULLTEXT KEY `product_fulltext` (`name`,`description`);

--
-- Indexes for table `product_category`
--
ALTER TABLE `product_category`
  ADD KEY `fk_product_category_1` (`product_id`),
  ADD KEY `fk_product_category_2` (`category_id`);

--
-- Indexes for table `product_image`
--
ALTER TABLE `product_image`
  ADD KEY `fk_table_images` (`product_id`);

--
-- Indexes for table `product_order`
--
ALTER TABLE `product_order`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_order_detail`
--
ALTER TABLE `product_order_detail`
  ADD PRIMARY KEY (`id`,`user_id`),
  ADD KEY `fk_table_orders_item` (`order_id`);

--
-- Indexes for table `shipping`
--
ALTER TABLE `shipping`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `location` (`location`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_username` (`username`),
  ADD UNIQUE KEY `unique_email` (`email`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `app_version`
--
ALTER TABLE `app_version`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `currency`
--
ALTER TABLE `currency`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=165;

--
-- AUTO_INCREMENT for table `fcm`
--
ALTER TABLE `fcm`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `news_info`
--
ALTER TABLE `news_info`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=150;

--
-- AUTO_INCREMENT for table `product_order`
--
ALTER TABLE `product_order`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `product_order_detail`
--
ALTER TABLE `product_order_detail`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `shipping`
--
ALTER TABLE `shipping`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=111;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` bigint(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `product_category`
--
ALTER TABLE `product_category`
  ADD CONSTRAINT `fk_product_category_1` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_product_category_2` FOREIGN KEY (`category_id`) REFERENCES `category` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `product_image`
--
ALTER TABLE `product_image`
  ADD CONSTRAINT `fk_table_images` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `product_order_detail`
--
ALTER TABLE `product_order_detail`
  ADD CONSTRAINT `fk_table_orders_item` FOREIGN KEY (`order_id`) REFERENCES `product_order` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
