<?php

if (!empty($_POST['email'])) {
    $email = $_POST['email'];
    $conn = mysqli_connect("localhost", "id21025329_ekrushi", "Pass@123");
    mysqli_select_db($conn, "id21025329_ekrushi");

    if ($conn) {
        try {
            $otp = random_int(100000, 999999);
        } catch (Exception $e) {
            $otp = rand(100000, 999999);
        }

        // Prepare the SQL statement
        $sql = "UPDATE users SET reset_password_otp = ?, reset_password_created_at = ? WHERE email = ?";

        // Prepare the statement
        $stmt = mysqli_prepare($conn, $sql);

        $currentDateTime = date('y-m-d H:i:s');

        // Bind the parameters
        mysqli_stmt_bind_param($stmt, "sss", $otp, $currentDateTime, $email);

        // Execute the statement
        if (mysqli_stmt_execute($stmt)) {
            if (mysqli_stmt_affected_rows($stmt)) {
                 $response = $otp; // Return the OTP
            } else {
                 $response = "Reset Password Failed";
            }
        } else {
             $response = "Reset Password Failed: " . mysqli_error($conn);
        }

        // Close the statement and database connection
        mysqli_stmt_close($stmt);
        mysqli_close($conn);
    } else {
         $response = "Database connection error";
    }
} else {
     $response = "All fields are required";
}
echo $response;

?>