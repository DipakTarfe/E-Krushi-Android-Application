<?php
$conn = mysqli_connect("localhost", "id21025329_ekrushi", "Pass@123");
mysqli_select_db($conn, "id21025329_ekrushi");

// Check if the database connection was successful
if (!$conn) {
    die("Database connection failed: " . mysqli_connect_error());
}

// Endpoint for fetching cart products
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['user_id'])) {
    $user_id = $_POST['user_id'];

    // Fetch cart products from the cart_product and products tables based on the user's ID
    $query = "SELECT cp.*, p.* FROM cart_product cp INNER JOIN product p ON cp.product_id = p.id WHERE cp.user_id = '$user_id'";
    $result = mysqli_query($conn, $query);

    $cartProducts = array();
    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            $cartProducts[] = $row;
        }

        $response = array(
            "status" => "success",
            "cartProducts" => $cartProducts
        );
    } else {
        $response = array(
            "status" => "error",
            "message" => "Cart is empty"
        );
    }

    header('Content-Type: application/json');
    echo json_encode($response);
}

// Close the database connection
mysqli_close($conn);
?>