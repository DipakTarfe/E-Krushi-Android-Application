<?php
$conn = mysqli_connect("localhost", "id21025329_ekrushi", "Pass@123");
mysqli_select_db($conn, "id21025329_ekrushi");

// Check if the database connection was successful
if (!$conn) {
    die("Database connection failed: " . mysqli_connect_error());
}

// Endpoint for fetching cart products
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['user_id'])) {
    $user_id = $_POST['user_id'];

    // Fetch cart products from the cart_product and products tables based on the user's ID
$query = "SELECT pod.*, po.*, p.*, po.code as order_id,po.id as id, po.status as order_status, pod.created_at as order_created_at 
          FROM product_order_detail pod  
          INNER JOIN product_order po ON pod.order_id = po.id 
          INNER JOIN product p ON pod.product_id = p.id 
          WHERE pod.user_id = '$user_id' 
          AND po.user_id = '$user_id'";
    $result = mysqli_query($conn, $query);

    $orderList = array();
    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            $orderList[] = $row;
        }

        $response = array(
            "status" => "success",
            "orderList" => $orderList
        );
    } else {
        $response = array(
            "status" => "error",
            "message" => "Order not found"
        );
    }

    header('Content-Type: application/json');
    echo json_encode($response);
}

// Close the database connection
mysqli_close($conn);
?>