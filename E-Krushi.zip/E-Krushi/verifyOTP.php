<?php
if (!empty($_POST['otp'])) {
    $otp = $_POST['otp'];

    $conn = mysqli_connect("localhost", "id21025329_ekrushi", "Pass@123");
    mysqli_select_db($conn, "id21025329_ekrushi");

    if ($conn) {
        $sql = "SELECT * FROM users WHERE reset_password_otp = ?";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "s", $otp);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        if (mysqli_num_rows($result) > 0) {
            echo "success";
        } else {
            echo "Invalid OTP";
        }

        mysqli_stmt_close($stmt);
        mysqli_close($conn);
    } else {
        echo "Database connection error";
    }
} else {
    echo "OTP field is required";
}
?>