<?php
// Check if the request method is POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if the 'userEmail' and 'image' parameters exist
    if (isset($_POST['userEmail']) && isset($_POST['image'])) {
        $userEmail = $_POST['userEmail'];
        $imageData = $_POST['image'];

        // Database connection details
        $servername = "localhost";
        $username = "id20929062_ekrushi";
        $password = "Pass@123";
        $dbname = "id20929062_ekrushi";

        // Create connection
        $conn = new mysqli($servername, $username, $password, $dbname);

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Prepare and execute the SQL statement to update the user's profile image
        $stmt = $conn->prepare("UPDATE users SET profile_image = ? WHERE email = ?");
        $stmt->bind_param("ss", $imageData, $userEmail);

        if ($stmt->execute()) {
            // Profile image updated successfully
            echo "success";
        } else {
            // Failed to update profile image
            echo "Failed to update profile image";
        }

        // Close the prepared statement and database connection
        $stmt->close();
        $conn->close();
    } else {
        // Required parameters are missing
        echo "Required parameters are missing";
    }
} else {
    // Invalid request method
    echo "Invalid request method";
}
?>