<?php
$conn = mysqli_connect("localhost", "id21025329_ekrushi", "Pass@123", "id21025329_ekrushi");

// Fetch user details based on email
function getUserDetails($email, $conn) {
    // Prepare the SQL statement
    $query = "SELECT name, email, phone, user_id FROM users WHERE email = ?";
    
    // Create a prepared statement
    $stmt = $conn->prepare($query);
    
    // Bind the email parameter to the statement
    $stmt->bind_param("s", $email);
    
    // Execute the statement
    $stmt->execute();
    
    // Bind the result to variables
    $stmt->bind_result($name, $email, $phone, $user_id);
    
    // Fetch the result
    $stmt->fetch();
    
    // Close the statement
    $stmt->close();
    
    // Return the user details as an associative array
    return array(
        'name' => $name,
        'email' => $email,
        'phone' => $phone,
        'user_id' => $user_id
    );
}

// Check if the email parameter is set
if (isset($_POST['email'])) {
    // Retrieve the email parameter value
    $email = $_POST['email'];
    
$conn = mysqli_connect("localhost", "id20929062_ekrushi", "Pass@123", "id20929062_ekrushi");
    
    // Fetch user details based on email
    $userDetails = getUserDetails($email, $conn);
    
    // Check if user details were found
    if ($userDetails) {
        // Return the user details as a JSON response
        echo json_encode($userDetails);
    } else {
        // Return an error message if user details were not found
        echo json_encode(array('error' => 'User details not found.'));
    }
    
    // Close the database connection
    $conn->closeConnection(); // Replace with your own code to close the database connection
} else {
    // Return an error message if the email parameter is missing
    echo json_encode(array('error' => 'Email parameter is missing.'));
}
?>
