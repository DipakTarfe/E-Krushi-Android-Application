<?php
$conn = mysqli_connect("localhost", "id21025329_ekrushi", "Pass@123");
mysqli_select_db($conn, "id21025329_ekrushi");

$user_id = $_POST['user_id'];
$product_id = $_POST['product_id'];
$quantity = $_POST['quantity'];

// Check if the product is already in the cart
$qry1 = "SELECT * FROM `cart_product` WHERE `product_id` = '$product_id'";
$raw = mysqli_query($conn, $qry1);

if (!$raw) {
    $response = "Error: " . mysqli_error($conn);
} else {
    if (mysqli_num_rows($raw) > 0) {
        $response = "Product already in the cart";
    } else {
        // Check if the product exists in the product table
        $qry2 = "SELECT * FROM `product` WHERE `id` = '$product_id'";
        $result = mysqli_query($conn, $qry2);
        if (!$result) {
            $response = "Error: " . mysqli_error($conn);
        } else {
            if (mysqli_num_rows($result) > 0) {
                // Add the product to the cart
                $qry3 = "INSERT INTO `cart_product` (user_id, product_id, quantity) VALUES ('$user_id', '$product_id','$quantity')";
                $res = mysqli_query($conn, $qry3);
                if ($res) {
                    $response = "Product added to cart";
                } else {
                    $response = "Failed to add product to cart: " . mysqli_error($conn);
                }
            } else {
                $response = "Product not found";
            }
        }
    }
}

echo $response;
?>