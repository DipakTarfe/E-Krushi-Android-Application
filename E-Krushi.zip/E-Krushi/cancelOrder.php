<?php
if (!empty($_POST['id']) && !empty($_POST['email'])) {
    $id = $_POST['id'];
    $email = $_POST['email'];

    $conn = mysqli_connect("localhost", "id21025329_ekrushi", "Pass@123");
    mysqli_select_db($conn, "id21025329_ekrushi");

    if ($conn) {
        $updateSql = "UPDATE `product_order` SET `status` = 'CANCEL' WHERE `product_order`.id = ? AND `product_order`.email = ?";
        $stmt = mysqli_prepare($conn, $updateSql);
        mysqli_stmt_bind_param($stmt, "ss", $id,$email);

        if (mysqli_stmt_execute($stmt)) {
            echo "success";
        } else {
            echo "Status canceled Failed: " . mysqli_error($conn);
        }

        mysqli_stmt_close($stmt);
        mysqli_close($conn);
    } else {
        echo "Database connection error";
    }
} else {
    echo "All fields are required";
}
?>