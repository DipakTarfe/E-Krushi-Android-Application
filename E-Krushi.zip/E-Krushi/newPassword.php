<?php
if (!empty($_POST['email']) && !empty($_POST['new_password'])) {
    $email = $_POST['email'];
    $new_password = $_POST['new_password'];

    $conn = mysqli_connect("localhost", "id21025329_ekrushi", "Pass@123");
    mysqli_select_db($conn, "id21025329_ekrushi");

    if ($conn) {
        $updateSql = "UPDATE users SET password = ? WHERE email = ?";
        $stmt = mysqli_prepare($conn, $updateSql);
        mysqli_stmt_bind_param($stmt, "ss", $new_password, $email);

        if (mysqli_stmt_execute($stmt)) {
            echo "success";
        } else {
            echo "Reset Password Failed: " . mysqli_error($conn);
        }

        mysqli_stmt_close($stmt);
        mysqli_close($conn);
    } else {
        echo "Database connection error";
    }
} else {
    echo "All fields are required";
}
?>