<?php
$conn=mysqli_connect("localhost", "id21025329_ekrushi", "Pass@123");
mysqli_select_db($conn,"id21025329_ekrushi");

// Retrieve the user ID and product ID from the request
$userID = $_POST['user_id'];
$productID = $_POST['product_id'];

// Check if the user ID and product ID are valid
if ($userID && $productID) {
    // Construct the SQL query to delete the cart product
    $sql = "DELETE FROM cart_product WHERE user_id = $userID AND product_id = $productID";

    // Execute the query
    if (mysqli_query($conn, $sql)) {
        // Deletion successful
        $response = array(
            'status' => 'success',
            'message' => 'Product removed from cart'
        );
        echo json_encode($response);
    } else {
        // Deletion failed
        $response = array(
            'status' => 'error',
            'message' => 'Error deleting cart product'
        );
        echo json_encode($response);
    }
} else {
    // Invalid user ID or product ID
    $response = array(
        'status' => 'error',
        'message' => 'Invalid user ID or product ID'
    );
    echo json_encode($response);
}
?>
