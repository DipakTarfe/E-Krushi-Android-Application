<?php
$conn = mysqli_connect("localhost", "id21025329_ekrushi", "Pass@123");
mysqli_select_db($conn, "id21025329_ekrushi");

$name = trim($_POST['name']);
$email = trim($_POST['email']);
$phone = trim($_POST['phone']);
$password = trim($_POST['password']);

$qry1 = "SELECT * FROM users WHERE email = '$email'";
$raw = mysqli_query($conn, $qry1);
$count = mysqli_num_rows($raw);

if ($count > 0) {
    $response = "User already exists";
} else {
    $qry2 = "INSERT INTO users (`user_id`, `name`, `password`, `email`, `phone`,`reset_password_otp`, `reset_password_created_at`) VALUES (NULL,'$name', '$password', '$email', '$phone', '000000', CURRENT_TIMESTAMP)";
    $res = mysqli_query($conn, $qry2);

    if ($res) {
        $response = "Registered Successfully";
    } else {
        $response = "Failed to register" . mysqli_error($conn);
    }
}

echo $response;
?>