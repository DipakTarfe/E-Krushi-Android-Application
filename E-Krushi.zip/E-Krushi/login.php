<?php
$conn = mysqli_connect("localhost", "id21025329_ekrushi", "Pass@123", "id21025329_ekrushi");

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$email = trim($_POST['email']);
$password = trim($_POST['password']);

// Validate user input
if (empty($email) || empty($password)) {
    $response = "Please enter both email and password";
} else {
    // Prepare the SQL statement using prepared statements
    $loginSql = "SELECT * FROM users WHERE email = ? AND password = ?";
    $loginStmt = mysqli_prepare($conn, $loginSql);

    if (!$loginStmt) {
        die("Prepare failed: " . mysqli_error($conn));
    }

    mysqli_stmt_bind_param($loginStmt, "ss", $email, $password);

    // Execute the login prepared statement
    mysqli_stmt_execute($loginStmt);

    if (mysqli_stmt_errno($loginStmt)) {
        die("Statement execution failed: " . mysqli_stmt_error($loginStmt));
    }

    // Get the login result
    $loginResult = mysqli_stmt_get_result($loginStmt);

    if (mysqli_num_rows($loginResult) > 0) {
        $response = "Logged in successfully";
    } else {
        $response = "Invalid email or password";
    }
}

echo $response;
?>
